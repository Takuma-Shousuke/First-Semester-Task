#pragma once

#include "DxLib.h"

#define WINDOW_W	640
#define WINDOW_H	360

