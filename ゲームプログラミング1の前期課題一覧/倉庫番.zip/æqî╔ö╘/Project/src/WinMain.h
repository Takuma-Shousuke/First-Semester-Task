#pragma once

#include "DxLib.h"
